"""Decode and print the verified double-anchor PK WebSocket messages.

Armies pushes are partial ranking snapshots, not the HTTP full contribution
list. They do not carry a battle ID: ``context_battle_id`` is only an inference
from a live, time-compatible lifecycle/score event, never a confirmed ID.
"""
from collections import OrderedDict
from google.protobuf.message import Message

from static import PK_pb2


PK_MESSAGES = {
    'LinkMicMethod': PK_pb2.LinkMicMethod,
    'LinkMicArmiesMethod': PK_pb2.LinkMicArmies,
    'LinkMicBattleMethod': PK_pb2.LinkMicBattle,
    'LinkMicBattleFinishMethod': PK_pb2.LinkMicBattleFinish,
}


def _id(number, explicit=''):
    return explicit or (str(number) if number else None)


def _time_ms(value):
    # Common.create_time has appeared in both seconds and milliseconds.
    return value * 1000 if 0 < value < 100_000_000_000 else value


def _ranks(users):
    return [dict(rank=index, uid=_id(u.user_id, getattr(u, 'user_id_str', '')),
                 nickname=u.nickname, score=str(u.score))
            for index, u in enumerate(users, 1)]


def _scores(users):
    return [dict(anchor_id=_id(u.user_id, u.user_id_str), score=str(u.score),
                 score_blur_text=u.score_blur_text,
                 score_relative_text=u.score_relative_text,
                 battle_rank=int(u.battle_rank)) for u in users]


def decode_pk_message(method, m: Message, msg_id=0):
    """Return a normalized PK event, or None for a non-PK/other LinkMic event.

    All exposed 64-bit IDs and scores are strings. Protobuf DecodeError is
    deliberately left to the caller so a bad item cannot discard later items.
    """
    event = dict(method=method, msg_id=_id(msg_id or m.common.msg_id),
                 room_id=_id(m.common.room_id),
                 create_time_ms=_time_ms(m.common.create_time),
                 battle_id=None, channel_id=None, context_battle_id=None,
                 context_channel_id=None)
    if method == 'LinkMicMethod':
        if m.message_type != 202:
            return None
        event.update(type='scores', battle_id=_id(m.battle_id, m.battle_id_str),
                     channel_id=_id(m.channel_id), scores=_scores(m.user_scores))
    elif method == 'LinkMicArmiesMethod':
        event.update(type='armies', is_complete=False,
                     anchors=[dict(anchor_id=str(anchor), users=_ranks(army.user_armies))
                              for anchor, army in sorted(m.user_armies_map.items())],
                     unassigned_armies=[_ranks(army.user_armies) for army in m.user_armies_list],
                     has_unsupported_rank_list_v2=bool(m.rank_list_v2))
    else:
        settings = m.battle_settings
        event.update(battle_id=_id(settings.battle_id, settings.battle_id_str),
                     channel_id=_id(settings.channel_id, settings.channel_id_str),
                     start_time_ms=settings.start_time_ms,
                     duration=int(settings.duration), battle_status=int(settings.battle_status))
        if method == 'LinkMicBattleFinishMethod':
            event.update(type='finish', is_complete=False,
                         end_reason=m.end_reason,
                         scores=_scores(m.battle_scores),
                         anchors=[dict(anchor_id=_id(army.anchor_id, army.anchor_id_str),
                                       users=_ranks(army.rank_list)) for army in m.battle_armies])
        else:
            event['type'] = 'start' if settings.battle_status == 1 else 'status'
    return event


class PKMessageHandler:
    """Bounded deduplication and conservative context for a single connection."""

    def __init__(self):
        self.active = None
        self._seen = OrderedDict()
        self._finished = OrderedDict()

    @staticmethod
    def _remember(cache, key, limit=512):
        duplicate = key in cache
        cache[key] = None
        cache.move_to_end(key)
        if len(cache) > limit:
            cache.popitem(last=False)
        return duplicate

    def handle(self, method, message: Message, msg_id=0):
        event = decode_pk_message(method, message, msg_id)
        if event is None:
            return None
        if event['msg_id'] and self._remember(
                self._seen, (method.removeprefix('Webcast'), event['msg_id'])):
            return None
        kind, battle_id = event['type'], event['battle_id']
        if kind == 'finish':
            # Some finishes have distinct message IDs but identical results.
            # The two anchor arrays can also be reversed between deliveries.
            finish_key = (battle_id,
                          repr(sorted(event['scores'], key=lambda s: s['anchor_id'] or '')),
                          repr(sorted(event['anchors'], key=lambda a: a['anchor_id'] or '')),
                          event['end_reason'])
            if battle_id and self._remember(self._seen, finish_key):
                return None
            if battle_id:
                self._remember(self._finished, battle_id, limit=128)
            if self.active and battle_id == self.active['battle_id']:
                self.active = None
        elif kind in ('start', 'scores') and battle_id and battle_id not in self._finished:
            since = event.get('start_time_ms') or event['create_time_ms']
            same_battle = self.active and battle_id == self.active['battle_id']
            # Delayed messages for an older battle must not replace the current one.
            if same_battle:
                self.active['channel_id'] = event['channel_id'] or self.active['channel_id']
            elif not self.active or (since and since >= self.active['since']):
                self.active = dict(battle_id=battle_id, channel_id=event['channel_id'], since=since)
        elif kind == 'status' and self.active and battle_id == self.active['battle_id']:
            if event['battle_status'] in (2, 3):
                self.active = None
        elif kind == 'armies' and self.active:
            since, created = self.active['since'], event['create_time_ms']
            if since and created and created >= since:
                event['context_battle_id'] = self.active['battle_id']
                event['context_channel_id'] = self.active['channel_id']
        return event


def print_pk_event(event):
    """Keep the default CLI useful while callback consumers receive full data."""
    battle = event['battle_id'] or '未知'
    if event['context_battle_id']:
        battle = f"{event['context_battle_id']}（按当前状态推定）"
    channel = event['channel_id'] or event['context_channel_id'] or '未知'
    labels = dict(start='PK 开始', status='PK 状态', scores='PK 比分',
                  armies='PK 贡献前三', finish='PK 结束')
    print(f"[{labels[event['type']]}] battle_id={battle} channel_id={channel}")
    if event['type'] in ('start', 'status'):
        print(f"  状态={event['battle_status']} 时长={event['duration']}秒")
    for score in event.get('scores', []):
        display = score['score_blur_text'] or score['score_relative_text'] or score['score']
        print(f"  主播UID={score['anchor_id']} PK值={display} 原始score={score['score']}")
    for anchor in event.get('anchors', []):
        print(f"  主播UID={anchor['anchor_id']} 贡献前三（推送快照，非完整榜单）")
        for user in anchor['users']:
            print(f"    #{user['rank']} UID={user['uid']} {user['nickname']} PK值={user['score']}")
        if not anchor['users']:
            print('    本次快照无用户')
    if event.get('unassigned_armies'):
        print('  另有未标明主播的贡献快照，详见 on_pk_event 的 unassigned_armies')
    if event.get('has_unsupported_rank_list_v2'):
        print('  收到 rank_list_v2：该玩法尚未解析，不能据此判断无人贡献')
